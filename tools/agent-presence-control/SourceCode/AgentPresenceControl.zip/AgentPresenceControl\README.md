# AgentPresenceControl

A Microsoft Power Apps Component Framework (PCF) control for **Dynamics 365 Contact Center (Omnichannel)** that provides supervisors with a real-time, searchable grid of all agent presence statuses — with history tracking, queue filtering, and the ability to override agent presence directly from the control.

---

## Overview

| Property | Value |
|---|---|
| **Control Type** | Virtual PCF (React) |
| **Namespace** | `AgentCC` |
| **Version** | 0.0.1 |
| **Publisher Prefix** | `acc` |
| **Minimum Required Role** | System Administrator or Omnichannel Supervisor |
| **Dataverse WebAPI** | Required |

---

## Features

### 🟢 Real-Time Agent Presence Grid
- Displays all Omnichannel agents with their current presence status, login state, and time in current presence
- Teams-style colour-coded presence icons (Available, Busy, Do Not Disturb, Be Right Back, Away, Offline)
- Auto-refreshes every **10 seconds** (toggle on/off)
- Manual refresh with last-updated timestamp

### 🔍 Search
- Instant agent name search with **200ms debounce** for performance at scale

### 📊 Status Summary Bar
- Colour-coded badge counts per presence status at the top of the grid
- **Clickable** — click any badge to filter the grid to only agents in that presence

### ↕️ Sorting
- Sort by **Agent Name** or **Presence** — ascending or descending

### 📁 Group By
- Group agents by **Presence Status** or **Logged In** state
- Groups are collapsible/expandable

### 🏷️ Queue Filter
- Filter agents by one or more **Omnichannel queues**
- Queue membership is fetched on-demand when queues are selected (not pre-loaded)
- Supports up to **5,000 queues** with concurrent fetching (max 5 parallel requests)

### 🔁 Change Agent Presence *(Authorized users only)*
- Click the **pencil icon** on any agent row to open the presence picker
- Only presences with `msdyn_canuserset = true` are shown
- Calls the CCaaS `ModifyAgentPresence` API to apply the change
- Role-gated: visible only to System Administrators and Omnichannel Supervisors

### 📅 Presence History — Last 24 Hours *(Inline)*
- Expand any agent row (chevron) to see an inline **24-hour presence timeline**
- Proportional colour bar + tabular detail (Presence, Start, End, Duration in `hh:mm:ss`)
- Inline refresh button to reload history on demand

### 🕐 Presence History — Last 7 Days *(Modal)*
- Click the **history icon** on any agent row to open a full history modal
- History grouped by **day**, with each day collapsible
- Per-day **proportional colour summary bar** and **presence legend pills**
- Click any legend pill to filter that day's timeline to a single presence status
- Timeline entries ordered **newest first**, with an "Active Now" badge for the current entry
- Modal has a fixed size (no resizing on filter/collapse interactions)
- Refresh button to reload data on demand

---

## Dataverse Tables Used

| Table | Purpose |
|---|---|
| `msdyn_agentstatus` | Agent current status (presence, login state, last modified) |
| `msdyn_presence` | All presence options and metadata |
| `msdyn_agentstatushistory` | Presence history records per agent |
| `queue` | Omnichannel queue list |
| `queuemembership` | Agent-to-queue membership associations |
| `systemuser` | Current user role check |

---

## Permissions & Authorization

The control performs a role check on load by reading the current user's assigned security roles:

| Role | Access Granted |
|---|---|
| **System Administrator** | Full access (change presence + view history icons) |
| **Omnichannel Supervisor** | Full access (change presence + view history icons) |
| **All other roles** | Read-only (grid, search, filter — no action buttons) |

> **Note:** Omnichannel Administrator Role is needed to perform presence change actions.

---

## CCaaS Presence Change API

When a supervisor changes an agent's presence, the control calls:

```
POST /api/data/v9.2/CCaaS_ModifyAgentPresence
```

```json
{
  "ApiVersion": "1.0",
  "AgentId": "<agent-systemuserid>",
  "PresenceId": "<msdyn_presenceid>"
}
```

GUIDs are normalised (lowercase, no curly braces) before sending.

---

## Scale & Performance

| Characteristic | Detail |
|---|---|
| **Supported agents** | Up to 30,000 |
| **Supported queues** | Up to 5,000 |
| **Agent data pagination** | 5,000 records per page via `@odata.nextLink` |
| **Virtual scrolling** | Only visible rows rendered (binary search, 8-row overscan) |
| **Queue fetch concurrency** | Max 5 parallel requests (`pLimit`) |
| **Search debounce** | 200ms |
| **Auto-refresh interval** | 10 seconds |
| **Change detection** | O(n) diff via stable agent Map — avoids unnecessary re-renders |
| **Bot/disabled user filtering** | Users with `applicationid` set or `isdisabled = true` are excluded |

---

## Grid Columns

| Column | Description |
|---|---|
| *(Expander)* | Expand/collapse inline 24h history panel |
| **Agent** | Agent full name (sortable) |
| *(Actions)* | History icon + Change Presence icon *(authorized users only)* |
| **Presence** | Teams-style presence icon with tooltip (sortable) |

---

## Project Structure

```
AgentPresenceControl/
├── AgentPresenceControl/
│   ├── AgentPresenceGrid.tsx       # Main React component (all UI, state, data fetching)
│   ├── PresenceIcon.tsx            # Teams-style SVG presence icons + resolvePresenceStatus()
│   ├── index.ts                    # PCF entry point
│   ├── ControlManifest.Input.xml   # Control manifest (WebAPI feature enabled)
│   └── generated/
│       └── ManifestTypes.d.ts      # Auto-generated manifest types
├── AgentPresenceControlSolution/
│   ├── src/Other/Solution.xml      # Solution metadata
│   └── bin/Release/
│       └── AgentPresenceControlSolution.zip  # Packaged managed solution
├── package.json
├── tsconfig.json
└── eslint.config.mjs
```

---

## Building

```bash
# Install dependencies
npm install

# Build the control
npm run build

# Package the solution (from solution folder)
cd AgentPresenceControlSolution
dotnet build --configuration Release
```

The packaged solution will be output to:
`AgentPresenceControlSolution\bin\Release\AgentPresenceControlSolution.zip`

---

## Deployment

1. Import `AgentPresenceControlSolution.zip` into your Dynamics 365 / Power Platform environment via the **Solutions** area in Power Apps Maker portal
2. Add the `AgentPresenceControl` PCF control to a model-driven app page or dashboard
3. Ensure the user viewing the control has **WebAPI** access and the required security roles

---

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| `@fluentui/react-components` | 9.x | UI components (Spinner, Badge, Menu, Input) |
| `@griffel/react` | — | CSS-in-JS via `makeStyles` |
| `react` | 16.14.0 | PCF React platform library |
| `p-limit` | — | Concurrency control for queue member fetches |
